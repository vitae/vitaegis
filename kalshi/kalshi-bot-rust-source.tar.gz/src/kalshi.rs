//! Signed Kalshi REST client and the WebSocket ticker feed.

use crate::config::Config;
use crate::model::dollars_to_cents;
use crate::{info, warn};
use anyhow::{anyhow, Context, Result};
use base64::{engine::general_purpose::STANDARD as B64, Engine};
use futures_util::{SinkExt, StreamExt};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{mpsc, watch};
use tokio_tungstenite::tungstenite::{client::IntoClientRequest, http::HeaderValue, Message};

pub const API_PREFIX: &str = "/trade-api/v2";
pub const WS_PATH: &str = "/trade-api/ws/v2";

/// Kalshi accepts Ed25519 (recommended) and RSA keys; it picks the algorithm from the key you registered.
pub enum Signer {
    Ed(ed25519_dalek::SigningKey),
    Rsa(rsa::pss::BlindedSigningKey<sha2::Sha256>),
}

impl Signer {
    pub fn load(path: &str) -> Result<Self> {
        use ed25519_dalek::pkcs8::DecodePrivateKey as _;
        let pem = std::fs::read_to_string(path).with_context(|| format!("private key file not found: {path}"))?;
        if let Ok(k) = ed25519_dalek::SigningKey::from_pkcs8_pem(&pem) {
            return Ok(Signer::Ed(k));
        }
        let rsa_key = {
            use rsa::pkcs1::DecodeRsaPrivateKey as _;
            use rsa::pkcs8::DecodePrivateKey as _;
            rsa::RsaPrivateKey::from_pkcs8_pem(&pem).or_else(|_| rsa::RsaPrivateKey::from_pkcs1_pem(&pem))
        }
        .map_err(|_| anyhow!("{path} is not an Ed25519 or RSA private key in PEM format"))?;
        Ok(Signer::Rsa(rsa::pss::BlindedSigningKey::new(rsa_key)))
    }

    pub fn sign(&self, msg: &[u8]) -> String {
        match self {
            Signer::Ed(k) => {
                use ed25519_dalek::Signer as _;
                B64.encode(k.sign(msg).to_bytes())
            }
            Signer::Rsa(k) => {
                use rsa::signature::{RandomizedSigner as _, SignatureEncoding as _};
                B64.encode(k.sign_with_rng(&mut rand::thread_rng(), msg).to_bytes())
            }
        }
    }
}

#[derive(Debug)]
pub struct KalshiError {
    pub status: u16, // 0 = network error
    pub body: String,
}
impl std::fmt::Display for KalshiError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        if self.status == 0 {
            write!(f, "network: {}", self.body)
        } else {
            write!(f, "HTTP {}: {}", self.status, self.body.chars().take(300).collect::<String>())
        }
    }
}
impl std::error::Error for KalshiError {}

pub struct Client {
    pub cfg: Config,
    http: reqwest::Client,
    signer: Option<Signer>,
}

impl Client {
    pub fn new(cfg: Config) -> Result<Self> {
        let signer = if cfg.key_id.is_empty() { None } else { Some(Signer::load(&cfg.private_key_path)?) };
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(10))
            .tcp_nodelay(true)
            .pool_idle_timeout(Duration::from_secs(90))
            .user_agent("vitaegis-kalshi-bot-rs")
            .build()?;
        Ok(Client { cfg, http, signer })
    }

    pub fn has_key(&self) -> bool {
        self.signer.is_some()
    }

    /// KALSHI-ACCESS-* headers, signed over timestamp_ms + METHOD + path (no query).
    pub fn auth_headers(&self, method: &str, path: &str) -> Option<[(&'static str, String); 3]> {
        let signer = self.signer.as_ref()?;
        let ts = (crate::util::now() * 1000.0) as i64;
        let sig = signer.sign(format!("{ts}{}{path}", method.to_uppercase()).as_bytes());
        Some([("KALSHI-ACCESS-KEY", self.cfg.key_id.clone()), ("KALSHI-ACCESS-TIMESTAMP", ts.to_string()), ("KALSHI-ACCESS-SIGNATURE", sig)])
    }

    async fn request(&self, method: &str, route: &str, query: &[(&str, String)], body: Option<Value>, auth: bool) -> Result<Value, KalshiError> {
        let path = format!("{API_PREFIX}{route}");
        let m = reqwest::Method::from_bytes(method.as_bytes()).unwrap();
        let mut req = self.http.request(m, format!("{}{path}", self.cfg.host)).query(query);
        if auth {
            for (k, v) in self.auth_headers(method, &path).ok_or(KalshiError { status: 401, body: "no API key configured".into() })? {
                req = req.header(k, v);
            }
        }
        if let Some(b) = body {
            req = req.json(&b);
        }
        let resp = req.send().await.map_err(|e| KalshiError { status: 0, body: e.to_string() })?;
        let status = resp.status().as_u16();
        if status == 429 {
            // honour Retry-After like SiddhaBasu's client; the caller's backoff adds to it
            let wait = resp.headers().get("retry-after").and_then(|v| v.to_str().ok()).and_then(|s| s.parse::<u64>().ok()).unwrap_or(1).min(30);
            tokio::time::sleep(Duration::from_secs(wait)).await;
        }
        let text = resp.text().await.map_err(|e| KalshiError { status: 0, body: e.to_string() })?;
        if status >= 400 {
            return Err(KalshiError { status, body: text });
        }
        serde_json::from_str(&text).map_err(|e| KalshiError { status, body: format!("bad JSON: {e}") })
    }

    pub async fn balance_cents(&self) -> Result<i64, KalshiError> {
        let v = self.request("GET", "/portfolio/balance", &[], None, true).await?;
        v["balance"].as_i64().ok_or(KalshiError { status: 200, body: "balance missing".into() })
    }

    pub async fn open_markets(&self) -> Result<Vec<Value>, KalshiError> {
        let q = [("series_ticker", self.cfg.series.clone()), ("status", "open".into()), ("limit", "100".into())];
        let v = self.request("GET", "/markets", &q, None, false).await?;
        Ok(v["markets"].as_array().cloned().unwrap_or_default())
    }

    pub async fn market(&self, ticker: &str) -> Result<Value, KalshiError> {
        Ok(self.request("GET", &format!("/markets/{ticker}"), &[], None, false).await?["market"].clone())
    }

    pub async fn orderbook(&self, ticker: &str) -> Result<Value, KalshiError> {
        Ok(self.request("GET", &format!("/markets/{ticker}/orderbook"), &[("depth", "10".into())], None, false).await?["orderbook"].clone())
    }

    pub async fn settled_page(&self, cursor: Option<&str>) -> Result<Value, KalshiError> {
        let mut q = vec![("series_ticker", self.cfg.series.clone()), ("status", "settled".into()), ("limit", "100".into())];
        if let Some(c) = cursor {
            q.push(("cursor", c.to_string()));
        }
        self.request("GET", "/markets", &q, None, false).await
    }

    pub async fn candlesticks(&self, ticker: &str, start: i64, end: i64) -> Result<Value, KalshiError> {
        let q = [("start_ts", start.to_string()), ("end_ts", end.to_string()), ("period_interval", "1".into())];
        self.request("GET", &format!("/series/{}/markets/{ticker}/candlesticks", self.cfg.series), &q, None, false).await
    }

    /// Buy `count` YES or NO contracts at `price` cents. Orders live on the YES book:
    /// buying NO at q is an ask (sell YES) at 100 - q.
    pub async fn buy(&self, ticker: &str, side: &str, price: i64, count: i64, client_order_id: &str) -> Result<Value, KalshiError> {
        let (book_side, book_cents) = crate::model::book_order(side, price);
        let body = json!({
            "ticker": ticker,
            "side": book_side,
            "count": count.to_string(),
            "price": format!("{:.4}", book_cents as f64 / 100.0),
            "time_in_force": self.cfg.time_in_force,
            "self_trade_prevention_type": "taker_at_cross",
            "client_order_id": client_order_id,
        });
        self.request("POST", "/portfolio/events/orders", &[], Some(body), true).await
    }
}

#[derive(Debug)]
pub struct Quote {
    pub ticker: String,
    pub yes: Option<i64>,
    pub no: Option<i64>,
}

/// Streams the `ticker` channel for whichever market `watch_rx` names; reconnects with backoff
/// and whenever the watched market changes. NO ask = 100 - YES bid.
pub async fn ticker_feed(client: Arc<Client>, mut watch_rx: watch::Receiver<Option<String>>, out: mpsc::Sender<Quote>, connected: Arc<AtomicBool>) {
    let mut backoff = 1u64;
    loop {
        let Some(ticker) = watch_rx.borrow_and_update().clone() else {
            if watch_rx.changed().await.is_err() {
                return;
            }
            continue;
        };
        match stream(&client, &ticker, &mut watch_rx, &out, &connected).await {
            Ok(()) => backoff = 1,
            Err(e) => {
                connected.store(false, Ordering::Relaxed);
                warn!("ws: {e}; reconnecting in {backoff}s");
                tokio::time::sleep(Duration::from_secs(backoff)).await;
                backoff = (backoff * 2).min(30);
            }
        }
    }
}

async fn stream(client: &Client, ticker: &str, watch_rx: &mut watch::Receiver<Option<String>>, out: &mpsc::Sender<Quote>, connected: &AtomicBool) -> Result<()> {
    let mut req = format!("{}{WS_PATH}", client.cfg.ws_host).into_client_request()?;
    for (k, v) in client.auth_headers("GET", WS_PATH).ok_or_else(|| anyhow!("no API key"))? {
        req.headers_mut().insert(k, HeaderValue::from_str(&v)?);
    }
    let (mut ws, _) = tokio_tungstenite::connect_async(req).await?;
    let sub = json!({"id": 1, "cmd": "subscribe", "params": {"channels": ["ticker"], "market_tickers": [ticker]}});
    ws.send(Message::Text(sub.to_string())).await?;
    connected.store(true, Ordering::Relaxed);
    info!("ws: streaming {ticker}");
    loop {
        tokio::select! {
            changed = watch_rx.changed() => {
                if changed.is_err() || watch_rx.borrow().as_deref() != Some(ticker) {
                    connected.store(false, Ordering::Relaxed);
                    let _ = ws.close(None).await;
                    return Ok(());
                }
            }
            msg = ws.next() => {
                let msg = msg.ok_or_else(|| anyhow!("connection closed"))??;
                match msg {
                    Message::Text(t) => {
                        let v: Value = serde_json::from_str(&t)?;
                        match v["type"].as_str() {
                            Some("ticker") => {
                                let m = &v["msg"];
                                if m["market_ticker"].as_str() == Some(ticker) {
                                    let yes_bid = dollars_to_cents(m.get("yes_bid_dollars"));
                                    let q = Quote { ticker: ticker.to_string(), yes: dollars_to_cents(m.get("yes_ask_dollars")), no: yes_bid.map(|b| 100 - b) };
                                    let _ = out.send(q).await;
                                }
                            }
                            Some("error") => return Err(anyhow!("server error {}", v["msg"])),
                            _ => {}
                        }
                    }
                    Message::Ping(p) => ws.send(Message::Pong(p)).await?,
                    Message::Close(_) => return Err(anyhow!("server closed the connection")),
                    _ => {}
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    /// Signs a fixed message with keys from KALSHI_TEST_KEYS (written by a Python script) so
    /// Python's `cryptography` can verify the signatures the way Kalshi does.
    #[test]
    fn sign_for_cross_check() {
        let Ok(dir) = std::env::var("KALSHI_TEST_KEYS") else { return };
        for name in ["ed", "rsa8", "rsa1"] {
            let s = super::Signer::load(&format!("{dir}/{name}.pem")).unwrap();
            std::fs::write(format!("{dir}/{name}.sig"), s.sign(b"1700000000000GET/trade-api/v2/portfolio/balance")).unwrap();
        }
    }
}
