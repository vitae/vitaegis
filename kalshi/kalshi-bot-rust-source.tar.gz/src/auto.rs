//! Hourly auto-test: replay every candidate on recent settled markets and keep only a strategy
//! that made money in BOTH the older and newer half (ranked by its weaker half). Else sit out.

use crate::btc::COINBASE;
use crate::kalshi::Client;
use crate::model::{candidates, dollars_to_cents, simulate, HistMarket, Pt, Sim, Strategy};
use crate::util::{now, parse_ts};
use crate::{info, warn};
use futures_util::{stream, StreamExt};
use serde::Serialize;
use serde_json::Value;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;

#[derive(Clone, Serialize)]
pub struct Row {
    pub label: String,
    #[serde(skip)]
    pub strategy: Strategy,
    pub older: Sim,
    pub newer: Sim,
    pub qualifies: bool,
    pub trades: i64,
    pub wins: i64,
    pub net: i64,
    pub score: i64,
}

#[derive(Clone, Serialize)]
pub struct AutoState {
    pub status: String,
    pub last_run: Option<f64>,
    pub sample: usize,
    pub min_trades: i64,
    pub report: Vec<Row>,
    pub expected_win: Option<f64>,
}

struct Cached {
    result: String,
    end: i64,
    strike: Option<f64>,
    raw: Vec<(i64, Option<i64>, Option<i64>)>, // (minute end ts, yes ask, no ask)
}

pub fn spawn(client: Arc<Client>, auto: Arc<Mutex<AutoState>>, strategy: Arc<Mutex<Option<Strategy>>>, disabled: Arc<Mutex<HashMap<String, f64>>>, retest: Arc<tokio::sync::Notify>) {
    tokio::spawn(async move {
        let http = reqwest::Client::builder().user_agent("vitaegis-kalshi-bot-rs").timeout(Duration::from_secs(15)).build().unwrap();
        let mut cache: HashMap<String, Cached> = HashMap::new();
        let mut btc: HashMap<i64, f64> = HashMap::new();
        loop {
            auto.lock().unwrap().status = "testing…".into();
            if let Err(e) = run_once(&client, &http, &mut cache, &mut btc, &auto, &strategy, &disabled).await {
                warn!("auto: test failed: {e}");
                auto.lock().unwrap().status = format!("test failed: {e}");
            }
            // hourly, or right away when the edge-decay guard pauses the active strategy
            tokio::select! {
                _ = tokio::time::sleep(Duration::from_secs(3600)) => {}
                _ = retest.notified() => info!("auto: re-testing early (a strategy was paused)"),
            }
        }
    });
}

async fn run_once(
    client: &Client,
    http: &reqwest::Client,
    cache: &mut HashMap<String, Cached>,
    btc: &mut HashMap<i64, f64>,
    auto: &Mutex<AutoState>,
    strategy: &Mutex<Option<Strategy>>,
    disabled: &Mutex<HashMap<String, f64>>,
) -> anyhow::Result<()> {
    let cfg = &client.cfg;
    // 1. recent settled markets
    let mut settled: Vec<Value> = Vec::new();
    let mut cursor: Option<String> = None;
    while settled.len() < cfg.auto_markets {
        let page = retry(|| client.settled_page(cursor.as_deref())).await?;
        let markets = page["markets"].as_array().cloned().unwrap_or_default();
        settled.extend(markets.iter().filter(|m| matches!(m["result"].as_str(), Some("yes" | "no"))).cloned());
        cursor = page["cursor"].as_str().filter(|c| !c.is_empty()).map(String::from);
        if cursor.is_none() || markets.is_empty() {
            break;
        }
    }
    settled.truncate(cfg.auto_markets);

    // 2. minute candles for markets not cached yet (6 at a time)
    let new: Vec<(String, String, i64, Option<f64>)> = settled
        .iter()
        .filter_map(|m| {
            let t = m["ticker"].as_str()?.to_string();
            let end = parse_ts(m["close_time"].as_str()?)? as i64;
            (!cache.contains_key(&t)).then(|| (t, m["result"].as_str().unwrap_or("").to_string(), end, m["floor_strike"].as_f64()))
        })
        .collect();
    let fetched: Vec<_> = stream::iter(new)
        .map(|(t, result, end, strike)| async move {
            let data = retry(|| client.candlesticks(&t, end - 900, end)).await.unwrap_or(Value::Null);
            let raw = data["candlesticks"].as_array().map(|cs| {
                cs.iter()
                    .filter_map(|k| {
                        let e = k["end_period_ts"].as_i64()?;
                        let yb = dollars_to_cents(k["yes_bid"].get("close_dollars"));
                        Some((e, dollars_to_cents(k["yes_ask"].get("close_dollars")), yb.map(|b| 100 - b)))
                    })
                    .collect::<Vec<_>>()
            });
            (t, result, end, strike, raw.unwrap_or_default())
        })
        .buffer_unordered(6)
        .collect()
        .await;
    for (t, result, end, strike, raw) in fetched {
        if !raw.is_empty() {
            cache.insert(t, Cached { result, end, strike, raw });
        }
    }

    // 3. BTC 1-minute closes covering the sample
    let ends: Vec<i64> = settled.iter().filter_map(|m| cache.get(m["ticker"].as_str()?).map(|c| c.end)).collect();
    let (Some(&lo), Some(&hi)) = (ends.iter().min(), ends.iter().max()) else {
        auto.lock().unwrap().status = "no market history available".into();
        return Ok(());
    };
    let mut t = lo - 1500;
    while t < hi {
        let stop = (t + 299 * 60).min(hi);
        let have = (t - t % 60..stop - 120).step_by(600).all(|ts| btc.contains_key(&ts));
        if !have {
            for attempt in 0..4 {
                let r = http.get(format!("{COINBASE}/candles")).query(&[("granularity", "60".to_string()), ("start", t.to_string()), ("end", stop.to_string())]).send().await;
                if let Ok(r) = r {
                    if let Ok(rows) = r.json::<Vec<Vec<f64>>>().await {
                        for row in rows.iter().filter(|r| r.len() >= 5) {
                            btc.insert(row[0] as i64, row[4]);
                        }
                        break;
                    }
                }
                tokio::time::sleep(Duration::from_secs(1 + attempt)).await;
            }
        }
        t = stop;
    }
    let mom = |e: i64| -> Option<f64> { Some((btc.get(&(e - 60))? / btc.get(&(e - 360))?).ln()) };
    // GBM probability at that minute: spot = close 1 min before, vol = trailing 30 one-minute returns
    let p_yes = |e: i64, strike: f64, secs: i64| -> Option<f64> {
        let spot = *btc.get(&(e - 60))?;
        let rets: Vec<f64> = (1..=30).filter_map(|i| Some((btc.get(&(e - 60 * i))? / btc.get(&(e - 60 * (i + 1)))?).ln())).collect();
        if rets.len() < 20 {
            return None;
        }
        let vol = (rets.iter().map(|r| r * r).sum::<f64>() / rets.len() as f64).sqrt();
        Some(crate::model::prob(spot, strike, vol, secs))
    };

    // 4. build the sample, oldest first, and split in halves
    let mut sample: Vec<HistMarket> = settled
        .iter()
        .filter_map(|m| {
            let c = cache.get(m["ticker"].as_str()?)?;
            let mut pts: Vec<Pt> = c.raw.iter().map(|&(e, yes, no)| Pt { sec: c.end - e, yes, no, mom: mom(e), p_yes: c.strike.and_then(|k| p_yes(e, k, c.end - e)) }).collect();
            pts.sort_by_key(|p| -p.sec);
            Some(HistMarket { result: c.result.clone(), end: c.end, pts })
        })
        .collect();
    sample.sort_by_key(|m| m.end);
    let (older, newer) = sample.split_at(sample.len() / 2);

    // 5. test every candidate (strategies paused for live losses can't be picked)
    let paused: HashMap<String, f64> = disabled.lock().unwrap().iter().filter(|(_, u)| **u > now()).map(|(k, v)| (k.clone(), *v)).collect();
    let mut rows: Vec<Row> = candidates()
        .into_iter()
        .map(|s| {
            let a = simulate(&s, older, cfg.target_cents, cfg.max_risk_cents, cfg.max_spread);
            let b = simulate(&s, newer, cfg.target_cents, cfg.max_risk_cents, cfg.max_spread);
            let qualifies = a.trades >= cfg.auto_min_trades && b.trades >= cfg.auto_min_trades && a.net > 0 && b.net > 0 && !paused.contains_key(&s.label());
            Row { label: s.label(), strategy: s, older: a, newer: b, qualifies, trades: a.trades + b.trades, wins: a.wins + b.wins, net: a.net + b.net, score: a.net.min(b.net) }
        })
        .collect();
    rows.sort_by(|x, y| (y.qualifies, y.score).cmp(&(x.qualifies, x.score)));
    let best = rows.first().filter(|r| r.qualifies).cloned();
    *strategy.lock().unwrap() = best.as_ref().map(|r| r.strategy);

    let mut a = auto.lock().unwrap();
    a.sample = sample.len();
    a.last_run = Some(now());
    a.report = rows.into_iter().take(10).collect();
    a.expected_win = best.as_ref().map(|r| r.wins as f64 / r.trades.max(1) as f64);
    match best {
        Some(r) => {
            a.status = format!("trading: {}", r.label);
            info!("auto: picked {} (older {:+.2}, newer {:+.2} over {} markets)", r.label, r.older.net as f64 / 100.0, r.newer.net as f64 / 100.0, sample.len());
        }
        None => {
            a.status = "sitting out: no strategy made money in both halves".into();
            info!("auto: no strategy made money in both halves of {} markets; sitting out", sample.len());
        }
    }
    Ok(())
}

async fn retry<F, Fut>(mut f: F) -> anyhow::Result<Value>
where
    F: FnMut() -> Fut,
    Fut: std::future::Future<Output = Result<Value, crate::kalshi::KalshiError>>,
{
    let mut last = None;
    for attempt in 0..4u64 {
        match f().await {
            Ok(v) => return Ok(v),
            Err(e) => {
                let wait = if e.status == 429 { 2 + attempt * 2 } else { 1 + attempt };
                last = Some(e);
                tokio::time::sleep(Duration::from_secs(wait)).await;
            }
        }
    }
    Err(anyhow::anyhow!("{}", last.unwrap()))
}
