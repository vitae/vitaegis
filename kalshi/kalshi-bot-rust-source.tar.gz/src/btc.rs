//! Coinbase BTC-USD: spot every 2s, 1-minute candles every 60s (volatility + 5-min momentum).

use crate::model;
use crate::util::now;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;

pub const COINBASE: &str = "https://api.exchange.coinbase.com/products/BTC-USD";

#[derive(Default)]
pub struct Btc {
    pub price: Option<f64>,
    pub vol: Option<f64>, // stdev of 1-minute log returns
    pub history: Vec<(f64, f64)>,
    pub candles: HashMap<i64, f64>, // minute start -> close
    pub ok: bool,
}

impl Btc {
    /// Log return of BTC over ~5 minutes: spot now vs the close of the candle 5 minutes ago.
    pub fn momentum(&self) -> Option<f64> {
        let price = self.price?;
        let start = (now() as i64) / 60 * 60 - 360;
        let past = self.candles.get(&start).or_else(|| self.candles.get(&(start - 60)))?;
        Some((price / past).ln())
    }

    pub fn prob(&self, strike: Option<f64>, secs: i64) -> Option<f64> {
        Some(model::prob(self.price?, strike?, self.vol?, secs))
    }
}

pub fn spawn(btc: Arc<Mutex<Btc>>) {
    tokio::spawn(async move {
        let http = reqwest::Client::builder().user_agent("vitaegis-kalshi-bot-rs").timeout(Duration::from_secs(5)).build().unwrap();
        let mut last_candles = 0.0;
        loop {
            let spot = async { http.get(format!("{COINBASE}/ticker")).send().await?.json::<serde_json::Value>().await };
            match spot.await.ok().and_then(|v| v["price"].as_str().and_then(|p| p.parse::<f64>().ok())) {
                Some(p) => {
                    let mut b = btc.lock().unwrap();
                    b.price = Some(p);
                    b.history.push((now(), p));
                    let n = b.history.len();
                    if n > 300 {
                        b.history.drain(..n - 300);
                    }
                    b.ok = true;
                }
                None => btc.lock().unwrap().ok = false,
            }
            if now() - last_candles > 60.0 {
                let rows = async { http.get(format!("{COINBASE}/candles")).query(&[("granularity", "60")]).send().await?.json::<Vec<Vec<f64>>>().await };
                if let Ok(rows) = rows.await {
                    let mut sorted: Vec<_> = rows.iter().filter(|r| r.len() >= 5).map(|r| (r[0] as i64, r[4])).collect();
                    sorted.sort_by_key(|r| r.0);
                    let closes: Vec<f64> = sorted.iter().rev().take(31).rev().map(|r| r.1).collect();
                    let rets: Vec<f64> = closes.windows(2).map(|w| (w[1] / w[0]).ln()).collect();
                    let mut b = btc.lock().unwrap();
                    b.candles = sorted.into_iter().collect();
                    if rets.len() >= 10 {
                        b.vol = Some((rets.iter().map(|x| x * x).sum::<f64>() / rets.len() as f64).sqrt());
                    }
                    last_candles = now();
                }
            }
            tokio::time::sleep(Duration::from_secs(2)).await;
        }
    });
}
