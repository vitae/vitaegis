//! Pure trading math: prices, fees, sizing, strategies, backtest replay, probability model.

use serde::Serialize;
use serde_json::Value;

/// Kalshi fixed-point dollar string ("0.2800") or number -> cents, None outside 1..=99.
pub fn dollars_to_cents(v: Option<&Value>) -> Option<i64> {
    let f = match v? {
        Value::String(s) if !s.is_empty() => s.parse::<f64>().ok()?,
        Value::Number(n) => n.as_f64()?,
        _ => return None,
    };
    let c = (f * 100.0).round() as i64;
    (1..=99).contains(&c).then_some(c)
}

/// Kalshi taker fee: ceil(0.07 * C * P * (1 - P)) dollars, in cents.
pub fn fee_cents(count: i64, price: i64) -> i64 {
    let p = price as f64 / 100.0;
    (7.0 * count as f64 * p * (1.0 - p) - 1e-9).ceil() as i64
}

/// Fewest contracts whose win nets at least `target` after fees, capped by `max_risk`.
pub fn contracts_for(target: i64, max_risk: i64, price: i64) -> i64 {
    let cap = max_risk / price;
    let mut n = ((target as f64) / (100 - price) as f64).ceil().max(1.0) as i64;
    while n < cap && n * (100 - price) - fee_cents(n, price) < target {
        n += 1;
    }
    n.min(cap)
}

#[cfg_attr(not(test), allow(dead_code))]
pub fn pnl_cents(side: &str, result: &str, count: i64, price: i64, fee: i64) -> i64 {
    pnl_from_payout(side, count, price, fee, if result == "yes" { 100 } else { 0 })
}

/// P&L when a YES contract pays `yes_payout` cents (100 = YES won, 0 = NO won, anything in
/// between = an unusual settlement such as a void/refund). NO pays 100 - yes_payout.
pub fn pnl_from_payout(side: &str, count: i64, price: i64, fee: i64, yes_payout: i64) -> i64 {
    if count <= 0 {
        return -fee;
    }
    let payout = if side == "yes" { yes_payout } else { 100 - yes_payout };
    count * (payout - price) - fee
}

/// Kalshi V2 orders live on the YES book. Buying YES at p = bid at p; buying NO at q = ask
/// (sell YES) at 100 - q. A mistake here bets the wrong side on every trade, so it is tested.
pub fn book_order(side: &str, price: i64) -> (&'static str, i64) {
    if side == "yes" {
        ("bid", price)
    } else {
        ("ask", 100 - price)
    }
}

/// Spread of the book in cents: YES ask + NO ask - 100 (0 or more on a single book).
pub fn spread(yes: Option<i64>, no: Option<i64>) -> Option<i64> {
    Some(yes? + no? - 100)
}

#[derive(Clone, Copy, Debug, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Kind {
    Zone,
    Momentum,
    /// Buy a side when the GBM model's probability beats Kalshi's price by at least `thr`
    /// (in probability, e.g. 0.08 = 8 points) after the taker fee, and that ask is in lo..=hi.
    Edge,
}

/// When to buy and which side. Both kinds only act while seconds-to-close is in tmin..=tmax.
/// zone: buy whichever side's ask is in lo..=hi (only one side can be).
/// momentum: buy the side BTC is moving toward when |5-min log return| >= thr and that ask is in lo..=hi.
#[derive(Clone, Copy, Debug, PartialEq, Serialize)]
pub struct Strategy {
    pub kind: Kind,
    pub lo: i64,
    pub hi: i64,
    pub tmin: i64,
    pub tmax: i64,
    pub thr: f64,
}

fn mmss(s: i64) -> String {
    format!("{}:{:02}", s / 60, s % 60)
}

impl Strategy {
    pub fn label(&self) -> String {
        let win = format!("{}→{} left", mmss(self.tmax), mmss(self.tmin));
        match self.kind {
            Kind::Momentum => format!(
                "Momentum: BTC moved >{:.2}% in 5 min → buy that direction at {}–{}¢, {win}",
                self.thr * 100.0, self.lo, self.hi
            ),
            Kind::Zone => format!("Price zone: buy the side priced {}–{}¢, {win}", self.lo, self.hi),
            Kind::Edge => format!("Model edge: buy when GBM odds beat the price by ≥{:.0} pts after fees, at {}–{}¢, {win}", self.thr * 100.0, self.lo, self.hi),
        }
    }

    /// Edge of buying `ask` when the model says the side wins with probability `p`, in
    /// probability points after Kalshi's taker fee.
    pub fn edge(p: f64, ask: i64) -> f64 {
        let a = ask as f64 / 100.0;
        p - a - 0.07 * a * (1.0 - a)
    }

    #[cfg(test)]
    pub fn entry(&self, yes: Option<i64>, no: Option<i64>, secs: i64, mom: Option<f64>) -> Option<(&'static str, i64)> {
        self.entry_with(yes, no, secs, mom, None)
    }

    /// `p_yes`: model probability that YES wins (needed only by Kind::Edge).
    pub fn entry_with(&self, yes: Option<i64>, no: Option<i64>, secs: i64, mom: Option<f64>, p_yes: Option<f64>) -> Option<(&'static str, i64)> {
        if secs < self.tmin || secs > self.tmax {
            return None;
        }
        let inside = |v: Option<i64>| v.is_some_and(|x| x >= self.lo && x <= self.hi);
        match self.kind {
            Kind::Edge => {
                let p = p_yes?;
                let mut best: Option<(&'static str, i64, f64)> = None;
                for (side, ask, q) in [("yes", yes, p), ("no", no, 1.0 - p)] {
                    if !inside(ask) {
                        continue;
                    }
                    let e = Self::edge(q, ask.unwrap());
                    if e >= self.thr && best.is_none_or(|b| e > b.2) {
                        best = Some((side, ask.unwrap(), e));
                    }
                }
                best.map(|(s, a, _)| (s, a))
            }
            Kind::Momentum => {
                let m = mom?;
                if m.abs() < self.thr {
                    return None;
                }
                let (side, ask) = if m > 0.0 { ("yes", yes) } else { ("no", no) };
                inside(ask).then(|| (side, ask.unwrap()))
            }
            Kind::Zone => match (inside(yes), inside(no)) {
                (true, false) => Some(("yes", yes.unwrap())),
                (false, true) => Some(("no", no.unwrap())),
                _ => None,
            },
        }
    }
}

pub const WINDOWS: [(i64, i64); 4] = [(600, 840), (300, 600), (60, 300), (60, 840)];

pub fn candidates() -> Vec<Strategy> {
    let mut v = Vec::new();
    for (lo, hi) in [(12, 35), (55, 70), (65, 80), (70, 85)] {
        for (a, b) in WINDOWS {
            v.push(Strategy { kind: Kind::Zone, lo, hi, tmin: a, tmax: b, thr: 0.0 });
        }
    }
    for thr in [0.0005, 0.001, 0.0015] {
        for (a, b) in WINDOWS {
            v.push(Strategy { kind: Kind::Momentum, lo: 35, hi: 65, tmin: a, tmax: b, thr });
        }
    }
    for thr in [0.05, 0.10, 0.20] {
        for (a, b) in WINDOWS {
            v.push(Strategy { kind: Kind::Edge, lo: 10, hi: 90, tmin: a, tmax: b, thr });
        }
    }
    v
}

/// Fraction of bankroll to stake on a bet that wins (100 - ask) and loses ask with probability p,
/// scaled by `fraction` (0.15 like the SiddhaBasu bot). Negative edge -> 0.
pub fn kelly_fraction(p: f64, ask: i64, fraction: f64) -> f64 {
    let b = (100 - ask) as f64 / ask as f64; // net odds
    ((p * b - (1.0 - p)) / b).max(0.0) * fraction
}

/// Contracts available at or below `limit` on one side of the book, from Kalshi's orderbook
/// ("yes"/"no" arrays of [price_dollars, size] or [price_cents, size]). Buying YES at p consumes
/// NO bids priced <= 100 - p (and vice versa), since every YES ask is a NO bid.
pub fn depth_at_or_below(book: &Value, side: &str, limit: i64) -> i64 {
    let other = if side == "yes" { "no" } else { "yes" };
    let Some(levels) = book[other].as_array() else { return 0 };
    levels
        .iter()
        .filter_map(|l| {
            let lv = l.as_array()?;
            let price = match &lv[0] {
                Value::String(s) => (s.parse::<f64>().ok()? * 100.0).round() as i64,
                Value::Number(n) => { let f = n.as_f64()?; if f <= 1.0 { (f * 100.0).round() as i64 } else { f as i64 } }
                _ => return None,
            };
            let size = match &lv[1] { Value::String(s) => s.parse::<f64>().ok()?, Value::Number(n) => n.as_f64()?, _ => return None };
            // a NO bid at q fills a YES buy at 100 - q
            (100 - price <= limit).then_some(size as i64)
        })
        .sum()
}

/// One minute of a settled market: seconds to close, YES ask, NO ask, BTC 5-min log return.
#[derive(Clone, Debug)]
pub struct Pt {
    pub sec: i64,
    pub yes: Option<i64>,
    pub no: Option<i64>,
    pub mom: Option<f64>,
    pub p_yes: Option<f64>,
}

#[derive(Clone, Debug)]
pub struct HistMarket {
    pub result: String,
    pub end: i64,
    pub pts: Vec<Pt>, // earliest minute first (largest sec first)
}

#[derive(Clone, Copy, Debug, Default, Serialize)]
pub struct Sim {
    pub trades: i64,
    pub wins: i64,
    pub net: i64,
}

/// Replay settled markets minute by minute; the first qualifying minute is the trade.
pub fn simulate(s: &Strategy, markets: &[HistMarket], target: i64, risk: i64, max_spread: i64) -> Sim {
    let mut out = Sim::default();
    for m in markets {
        for p in &m.pts {
            if spread(p.yes, p.no).is_some_and(|sp| sp > max_spread) {
                continue; // same liquidity guard as live trading
            }
            let Some((side, ask)) = s.entry_with(p.yes, p.no, p.sec, p.mom, p.p_yes) else { continue };
            let count = contracts_for(target, risk, ask);
            if count < 1 {
                break;
            }
            let fee = fee_cents(count, ask);
            out.trades += 1;
            if side == m.result {
                out.wins += 1;
                out.net += count * (100 - ask) - fee;
            } else {
                out.net -= count * ask + fee;
            }
            break;
        }
    }
    out
}

/// erf via Abramowitz & Stegun 7.1.26 (error < 1.5e-7).
fn erf(x: f64) -> f64 {
    let s = x.signum();
    let x = x.abs();
    let t = 1.0 / (1.0 + 0.3275911 * x);
    let y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * (-x * x).exp();
    s * y
}

/// P(BTC finishes >= strike) under zero-drift geometric Brownian motion:
/// ln(S_T/S_0) ~ N(-σ_h²/2, σ_h²), σ_h = vol_1m·√minutes, so P = Φ((ln(S_0/K) - σ_h²/2) / σ_h).
/// Kalshi settles on a 60-second average, so the horizon is shortened by 30 seconds.
pub fn prob(price: f64, strike: f64, vol_1m: f64, secs: i64) -> f64 {
    let horizon = ((secs - 30).max(15)) as f64 / 60.0;
    let sigma = vol_1m.max(1e-5) * horizon.sqrt();
    let z = ((price / strike).ln() - 0.5 * sigma * sigma) / sigma;
    (0.5 * (1.0 + erf(z / std::f64::consts::SQRT_2)) * 10_000.0).round() / 10_000.0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sizing_matches_python() {
        // (price, max_risk) -> contracts, from the Python bot
        assert_eq!(contracts_for(750, 1500, 12), 9);
        assert_eq!(contracts_for(750, 1500, 20), 10);
        assert_eq!(contracts_for(750, 1500, 35), 12);
        assert_eq!(contracts_for(750, 800, 65), 12);
        assert_eq!(contracts_for(750, 800, 80), 10);
        assert_eq!(fee_cents(10, 20), 12);
    }

    #[test]
    fn zone_and_momentum_entries() {
        let z = Strategy { kind: Kind::Zone, lo: 65, hi: 80, tmin: 60, tmax: 840, thr: 0.0 };
        assert_eq!(z.entry(Some(72), Some(29), 500, None), Some(("yes", 72)));
        assert_eq!(z.entry(Some(30), Some(71), 500, None), Some(("no", 71)));
        assert_eq!(z.entry(Some(50), Some(51), 500, None), None);
        assert_eq!(z.entry(Some(72), Some(29), 30, None), None);
        let m = Strategy { kind: Kind::Momentum, lo: 35, hi: 65, tmin: 300, tmax: 600, thr: 0.001 };
        assert_eq!(m.entry(Some(55), Some(46), 400, Some(0.002)), Some(("yes", 55)));
        assert_eq!(m.entry(Some(55), Some(46), 400, Some(-0.002)), Some(("no", 46)));
        assert_eq!(m.entry(Some(55), Some(46), 400, Some(0.0005)), None);
    }

    #[test]
    fn order_book_mapping() {
        // Buying NO at 30¢ must be a YES ask at 70¢, never a bid (that would buy YES).
        assert_eq!(book_order("no", 30), ("ask", 70));
        assert_eq!(book_order("yes", 30), ("bid", 30));
        assert_eq!(spread(Some(18), Some(83)), Some(1));
    }

    #[test]
    fn pnl_including_unusual_settlements() {
        assert_eq!(pnl_cents("yes", "yes", 10, 70, 21), 10 * 30 - 21);
        assert_eq!(pnl_cents("no", "yes", 10, 30, 15), -(10 * 30) - 15);
        // a 50/50 refund: buying the favourite at 70 loses 20/contract, the longshot at 30 gains 20
        assert_eq!(pnl_from_payout("yes", 10, 70, 0, 50), -200);
        assert_eq!(pnl_from_payout("no", 10, 30, 0, 50), 200);
        assert_eq!(pnl_from_payout("yes", 0, 70, 0, 100), 0);
    }

    #[test]
    fn simulate_respects_spread_and_first_minute() {
        let s = Strategy { kind: Kind::Zone, lo: 65, hi: 80, tmin: 60, tmax: 840, thr: 0.0 };
        let m = HistMarket {
            result: "yes".into(),
            end: 0,
            pts: vec![
                Pt { sec: 800, yes: Some(70), no: Some(40), mom: None, p_yes: None }, // 10¢ spread: skipped
                Pt { sec: 700, yes: Some(72), no: Some(29), mom: None, p_yes: None }, // trade here
                Pt { sec: 600, yes: Some(75), no: Some(26), mom: None, p_yes: None }, // ignored (one per market)
            ],
        };
        let r = simulate(&s, &[m], 750, 800, 3);
        assert_eq!((r.trades, r.wins), (1, 1));
        let count = contracts_for(750, 800, 72);
        assert_eq!(r.net, count * 28 - fee_cents(count, 72));
    }

    #[test]
    fn prob_is_sane() {
        // at the strike the drift term makes it a hair under 50%, as GBM says
        assert!((prob(100.0, 100.0, 0.001, 300) - 0.5).abs() < 0.01);
        assert!(prob(101.0, 100.0, 0.001, 300) > 0.99);
        assert!(prob(99.0, 100.0, 0.001, 300) < 0.01);
        assert_eq!(candidates().len(), 40);
    }

    #[test]
    fn edge_strategy_kelly_and_depth() {
        let e = Strategy { kind: Kind::Edge, lo: 10, hi: 90, tmin: 60, tmax: 840, thr: 0.05 };
        // model says 80% YES, YES asks 60¢ -> edge 0.80 - 0.60 - fee(0.0168) = 0.183 -> buy YES
        assert_eq!(e.entry_with(Some(60), Some(41), 400, None, Some(0.80)), Some(("yes", 60)));
        // model 55%: YES edge is negative, NO edge 0.45-0.41-0.017 = 0.023 < 0.05 -> nothing
        assert_eq!(e.entry_with(Some(60), Some(41), 400, None, Some(0.55)), None);
        assert_eq!(e.entry_with(Some(60), Some(41), 400, None, None), None);
        assert!((kelly_fraction(0.6, 50, 1.0) - 0.2).abs() < 1e-9);
        assert_eq!(kelly_fraction(0.4, 50, 1.0), 0.0);
        let book = serde_json::json!({"yes": [["0.2000", "50"]], "no": [["0.2800", "30"], ["0.3000", "40"], ["0.2500", "5"]]});
        // buying YES at <=72¢ consumes NO bids priced >= 28¢: 30 + 40 = 70
        assert_eq!(depth_at_or_below(&book, "yes", 72), 70);
        assert_eq!(depth_at_or_below(&book, "yes", 70), 40);
        // buying NO at <=80¢ consumes YES bids >= 20¢: 50
        assert_eq!(depth_at_or_below(&book, "no", 80), 50);
    }
}
