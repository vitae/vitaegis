//! Vitaegis Kalshi KXBTC15M bot (Rust).
//!
//! Dry run unless started with --live. Settings come from environment variables (see
//! deploy/kalshi-bot.env.example). The dashboard listens on KALSHI_HUB_ADDR (default
//! 127.0.0.1:8787); on a server, reach it with an SSH tunnel.

mod auto;
mod bot;
mod btc;
mod config;
mod kalshi;
mod model;
mod util;

use crate::auto::AutoState;
use crate::bot::Bot;
use crate::btc::Btc;
use crate::config::Config;
use crate::kalshi::{Client, Quote};
use crate::model::{Kind, Strategy};
use axum::{response::Html, routing::get, Json, Router};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::sync::{mpsc, watch};

const HUB_HTML: &str = include_str!("../hub.html");

#[derive(Clone)]
struct Shared {
    bot: Arc<Mutex<Bot>>,
    btc: Arc<Mutex<Btc>>,
    strategy: Arc<Mutex<Option<Strategy>>>,
    auto: Option<Arc<Mutex<AutoState>>>,
}

impl Shared {
    fn snapshot(&self) -> serde_json::Value {
        let auto = self.auto.as_ref().map(|a| a.lock().unwrap().clone());
        let strategy = *self.strategy.lock().unwrap();
        let btc = self.btc.lock().unwrap();
        self.bot.lock().unwrap().snapshot(&btc, strategy, auto.as_ref())
    }
}

#[tokio::main]
async fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        println!("kalshi-bot [--live] [--once]\n  --live  place real orders (default: dry run)\n  --once  one poll, then exit");
        return;
    }
    let live = args.iter().any(|a| a == "--live");
    let once = args.iter().any(|a| a == "--once");
    std::process::exit(match run(live, once).await {
        Ok(()) => 0,
        Err(e) => {
            error!("{e:#}");
            2
        }
    });
}

async fn run(live: bool, once: bool) -> anyhow::Result<()> {
    let cfg = Config::from_env(live)?;
    if live && cfg.key_id.is_empty() {
        anyhow::bail!("KALSHI_KEY_ID is required for --live");
    }
    let client = Arc::new(Client::new(cfg.clone())?);

    let mut balance = None;
    if client.has_key() {
        match client.balance_cents().await {
            Ok(b) => {
                info!("auth ok (key {}), balance ${:.2}", &cfg.key_id[..8.min(cfg.key_id.len())], b as f64 / 100.0);
                balance = Some(b);
            }
            Err(e) if e.status == 401 => anyhow::bail!(
                "Kalshi rejected key {} (401). Check: (1) KALSHI_KEY_ID matches the key whose private key file you saved; \
                 (2) the key was made on kalshi.com, not the demo site; (3) the server clock is right (timedatectl). Detail: {e}",
                cfg.key_id
            ),
            Err(e) => return Err(e.into()),
        }
    }
    if !live {
        info!("dry run: no orders will be placed (pass --live to trade)");
    }

    let shared = Shared {
        bot: Arc::new(Mutex::new(Bot::new(cfg.clone()))),
        btc: Arc::new(Mutex::new(Btc::default())),
        strategy: Arc::new(Mutex::new(Some(Strategy { kind: Kind::Zone, lo: cfg.min_entry, hi: cfg.max_entry, tmin: cfg.min_seconds, tmax: 900, thr: 0.0 }))),
        auto: (cfg.auto && !once).then(|| {
            Arc::new(Mutex::new(AutoState { status: "waiting for first test".into(), last_run: None, sample: 0, min_trades: cfg.auto_min_trades, report: vec![], expected_win: None }))
        }),
    };
    if let Some(b) = balance {
        shared.bot.lock().unwrap().set_balance(b);
    }
    btc::spawn(shared.btc.clone());

    if once {
        let markets = client.open_markets().await?;
        let now_s = util::now();
        let m = markets.iter().filter(|m| m["close_time"].as_str().and_then(util::parse_ts).is_some_and(|c| c > now_s)).min_by(|a, b| a["close_time"].as_str().cmp(&b["close_time"].as_str()));
        match m {
            Some(m) => {
                let mut bot = shared.bot.lock().unwrap();
                if let Some((t, y, n)) = bot.set_market(m) {
                    let c = bot::Ctx { strategy: *shared.strategy.lock().unwrap(), mom: None, auto_status: None, btc_age: None, expected_win: None, btc_price: None, btc_vol: None };
                    bot.observe(&t, y, n, "rest", &c);
                    info!("decision: {}", bot.decision.reason);
                }
            }
            None => info!("no open {} market", cfg.series),
        }
        return Ok(());
    }

    if let Some(a) = &shared.auto {
        *shared.strategy.lock().unwrap() = None; // nothing trades until the first test picks something
        let (disabled, retest) = {
            let b = shared.bot.lock().unwrap();
            (b.disabled.clone(), b.retest.clone())
        };
        auto::spawn(client.clone(), a.clone(), shared.strategy.clone(), disabled, retest);
        info!("auto: testing strategies on recent markets (takes a minute or two)…");
    }

    // dashboard
    if cfg.hub_addr != "0" {
        let s = shared.clone();
        let app = Router::new()
            .route("/", get(|| async { Html(HUB_HTML) }))
            .route("/state", get(move || {
                let s = s.clone();
                async move { Json(s.snapshot()) }
            }));
        match tokio::net::TcpListener::bind(&cfg.hub_addr).await {
            Ok(listener) => {
                info!("hub: dashboard at http://{}", cfg.hub_addr);
                tokio::spawn(async move { axum::serve(listener, app).await });
            }
            Err(e) => warn!("hub: can't listen on {} ({e}); dashboard off", cfg.hub_addr),
        }
    }

    // live quotes
    let (watch_tx, watch_rx) = watch::channel::<Option<String>>(None);
    let (quote_tx, mut quote_rx) = mpsc::channel::<Quote>(1024);
    let connected = Arc::new(AtomicBool::new(false));
    if client.has_key() {
        tokio::spawn(kalshi::ticker_feed(client.clone(), watch_rx, quote_tx, connected.clone()));
    } else {
        info!("ws: no KALSHI_KEY_ID; polling only");
    }

    let mut poll = tokio::time::interval(Duration::from_secs(cfg.poll_seconds));
    poll.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    let mut last_balance = Instant::now();
    let mut last_settle = Instant::now() - Duration::from_secs(60);
    let mut backoff_until = Instant::now();

    loop {
        tokio::select! {
            _ = poll.tick() => {
                if Instant::now() < backoff_until { continue; }
                shared.bot.lock().unwrap().new_day_check();
                // balance + floor (live only)
                if live && last_balance.elapsed() > Duration::from_secs(60) {
                    last_balance = Instant::now();
                    match client.balance_cents().await {
                        Ok(b) => shared.bot.lock().unwrap().set_balance(b),
                        Err(e) => warn!("balance: {e}"),
                    }
                }
                // discover the soonest-closing market
                match client.open_markets().await {
                    Ok(markets) => {
                        let now_s = util::now();
                        let m = markets.iter()
                            .filter_map(|m| Some((m, m["close_time"].as_str().and_then(util::parse_ts)?)))
                            .filter(|(_, c)| *c > now_s)
                            .min_by(|a, b| a.1.total_cmp(&b.1))
                            .map(|(m, _)| m.clone());
                        let c = ctx(&shared); // read other locks BEFORE taking the bot lock
                        let intent = {
                            let mut bot = shared.bot.lock().unwrap();
                            bot.streaming = connected.load(Ordering::Relaxed);
                            match m.as_ref().and_then(|m| bot.set_market(m)) {
                                Some((t, y, n)) => {
                                    let _ = watch_tx.send_if_modified(|cur| { if cur.as_deref() != Some(&t) { *cur = Some(t.clone()); true } else { false } });
                                    bot.observe(&t, y, n, "rest", &c)
                                }
                                None => { info!("no open {} market", cfg.series); bot.current = None; None }
                            }
                        };
                        if let Some(it) = intent { place(&client, &shared, it).await; }
                    }
                    Err(e) => {
                        error!("kalshi: {e}");
                        if e.status == 429 { backoff_until = Instant::now() + Duration::from_secs(30); }
                    }
                }
                // settlement pass every 30s
                if last_settle.elapsed() > Duration::from_secs(30) {
                    last_settle = Instant::now();
                    let due = shared.bot.lock().unwrap().due_for_settlement();
                    for t in due {
                        match client.market(&t).await {
                            Ok(m) => shared.bot.lock().unwrap().settle(&t, m["result"].as_str().unwrap_or("?"), yes_payout(&m)),
                            Err(e) => warn!("settle lookup {t}: {e}"),
                        }
                    }
                }
            }
            Some(q) = quote_rx.recv() => {
                let c = ctx(&shared);
                let intent = {
                    let mut bot = shared.bot.lock().unwrap();
                    bot.streaming = connected.load(Ordering::Relaxed);
                    bot.observe(&q.ticker, q.yes, q.no, "ws", &c)
                };
                if let Some(it) = intent { place(&client, &shared, it).await; }
            }
        }
    }
}

/// Lock order is auto -> strategy -> btc -> bot -> disabled everywhere; read these before taking `bot`.
fn ctx(shared: &Shared) -> bot::Ctx {
    let (auto_status, expected_win) = shared.auto.as_ref().map(|a| {
        let a = a.lock().unwrap();
        (Some(a.status.clone()), a.expected_win)
    }).unwrap_or((None, None));
    let strategy = *shared.strategy.lock().unwrap();
    let (mom, btc_age, btc_price, btc_vol) = {
        let b = shared.btc.lock().unwrap();
        (b.momentum(), b.history.last().map(|h| util::now() - h.0), b.price, b.vol)
    };
    bot::Ctx { strategy, mom, auto_status, btc_age, expected_win, btc_price, btc_vol }
}

/// Cents a YES contract paid: 100 / 0 for normal results, settlement_value for anything else
/// once the market is settled, None while it isn't.
fn yes_payout(m: &serde_json::Value) -> Option<i64> {
    match m["result"].as_str() {
        Some("yes") => Some(100),
        Some("no") => Some(0),
        _ if matches!(m["status"].as_str(), Some("settled" | "finalized")) => {
            let v = m.get("settlement_value_dollars").and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()).or(v.as_f64()))
                .or_else(|| m["settlement_value"].as_f64().map(|c| c / 100.0))?;
            Some((v * 100.0).round().clamp(0.0, 100.0) as i64)
        }
        _ => None,
    }
}

/// Send the order (live) or simulate it (dry run), with the safety halts.
async fn place(client: &Client, shared: &Shared, it: bot::Intent) {
    let live = client.cfg.live;
    let mut it = it;
    if live && client.cfg.check_depth {
        // Walk the real book like SiddhaBasu's fill model: only send what can fill at our limit.
        match client.orderbook(&it.ticker).await {
            Ok(book) => {
                let avail = model::depth_at_or_below(&book, it.side, it.price);
                if avail < 1 {
                    warn!("skip: no {} contracts offered at <= {}¢ right now (book moved)", it.side.to_uppercase(), it.price);
                    shared.bot.lock().unwrap().traded.remove(&it.ticker); // let a later quote retry this market
                    return;
                }
                if avail < it.count {
                    info!("book has only {avail} at <= {}¢; sizing down from {}", it.price, it.count);
                    it.count = avail;
                }
            }
            Err(e) => warn!("orderbook check failed ({e}); sending the IOC order anyway"),
        }
    }
    let started = Instant::now();
    let resp = if live {
        match client.buy(&it.ticker, it.side, it.price, it.count, &it.client_order_id).await {
            Ok(r) => {
                shared.bot.lock().unwrap().order_failures = 0;
                Some(r)
            }
            Err(e) => {
                let mut bot = shared.bot.lock().unwrap();
                bot.order_failures += 1;
                error!("order failed ({} in a row): {e}", bot.order_failures);
                if e.status == 401 {
                    bot.halt("Kalshi rejected the API key while ordering (401)".into());
                } else if bot.order_failures >= 5 {
                    bot.halt("5 orders in a row failed".into());
                }
                return;
            }
        }
    } else {
        None
    };
    let latency = live.then(|| started.elapsed().as_millis());
    let btc = shared.btc.lock().unwrap();
    shared.bot.lock().unwrap().record_order(&it, resp.as_ref(), latency, &btc);
}
