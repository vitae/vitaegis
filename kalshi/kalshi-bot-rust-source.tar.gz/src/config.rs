//! Settings from environment variables (same names as the Python bot).

use anyhow::{bail, Result};
use std::env;

#[derive(Clone, Debug)]
pub struct Config {
    pub key_id: String,
    pub private_key_path: String,
    pub host: String,
    pub ws_host: String,
    pub series: String,
    pub target_cents: i64,
    pub max_risk_cents: i64,
    pub daily_loss_cents: i64,
    pub min_balance_cents: i64,
    pub min_entry: i64,
    pub max_entry: i64,
    pub min_seconds: i64,
    pub max_orders_per_day: i64,
    pub poll_seconds: u64,
    pub time_in_force: String,
    pub settle_grace: i64,
    pub settle_timeout: i64,
    pub hub_addr: String,
    pub auto: bool,
    pub auto_markets: usize,
    pub auto_min_trades: i64,
    pub max_spread: i64,
    pub btc_stale_secs: f64,
    pub decay_trades: usize,
    pub decay_stop_cents: i64,
    pub drawdown_stop: f64,
    pub check_depth: bool,
    pub kelly_fraction: f64,
    pub live: bool,
}

fn get(k: &str, d: &str) -> String {
    env::var(k).ok().filter(|v| !v.is_empty()).unwrap_or_else(|| d.to_string())
}
fn cents(k: &str, d: &str) -> Result<i64> {
    Ok((get(k, d).parse::<f64>()? * 100.0).round() as i64)
}

impl Config {
    pub fn from_env(live: bool) -> Result<Self> {
        let cfg = Config {
            key_id: get("KALSHI_KEY_ID", ""),
            private_key_path: get("KALSHI_PRIVATE_KEY_PATH", "kalshi_private.key"),
            host: get("KALSHI_HOST", "https://external-api.kalshi.com").trim_end_matches('/').into(),
            ws_host: get("KALSHI_WS_HOST", "wss://external-api-ws.kalshi.com").trim_end_matches('/').into(),
            series: get("KALSHI_SERIES", "KXBTC15M"),
            target_cents: cents("KALSHI_TARGET_PROFIT_USD", "7.50")?,
            max_risk_cents: cents("KALSHI_MAX_RISK_USD", "8")?,
            daily_loss_cents: cents("KALSHI_DAILY_LOSS_LIMIT_USD", "10")?,
            min_balance_cents: cents("KALSHI_MIN_BALANCE_USD", "5")?,
            min_entry: get("KALSHI_MIN_ENTRY_CENTS", "65").parse()?,
            max_entry: get("KALSHI_MAX_ENTRY_CENTS", "80").parse()?,
            min_seconds: get("KALSHI_MIN_SECONDS_TO_CLOSE", "600").parse()?,
            max_orders_per_day: get("KALSHI_MAX_ORDERS_PER_DAY", "40").parse()?,
            poll_seconds: get("KALSHI_POLL_SECONDS", "15").parse()?,
            time_in_force: get("KALSHI_TIME_IN_FORCE", "immediate_or_cancel"),
            settle_grace: get("KALSHI_SETTLE_GRACE_SECONDS", "120").parse()?,
            settle_timeout: get("KALSHI_SETTLE_TIMEOUT_SECONDS", "21600").parse()?,
            hub_addr: get("KALSHI_HUB_ADDR", "127.0.0.1:8787"),
            auto: get("KALSHI_AUTO", "1") != "0",
            auto_markets: get("KALSHI_AUTO_MARKETS", "300").parse()?,
            auto_min_trades: get("KALSHI_AUTO_MIN_TRADES", "12").parse()?,
            max_spread: get("KALSHI_MAX_SPREAD_CENTS", "3").parse()?,
            btc_stale_secs: get("KALSHI_BTC_STALE_SECONDS", "10").parse()?,
            decay_trades: get("KALSHI_DECAY_TRADES", "12").parse()?,
            decay_stop_cents: cents("KALSHI_DECAY_STOP_USD", "16")?,
            drawdown_stop: get("KALSHI_DRAWDOWN_STOP", "0.25").parse()?,
            check_depth: get("KALSHI_CHECK_DEPTH", "1") != "0",
            kelly_fraction: get("KALSHI_KELLY_FRACTION", "0").parse()?,
            live,
        };
        if !(1 <= cfg.min_entry && cfg.min_entry <= cfg.max_entry && cfg.max_entry <= 99) {
            bail!("entry bounds must satisfy 1 <= min <= max <= 99 cents");
        }
        if cfg.target_cents <= 0 || cfg.max_risk_cents <= 0 || cfg.daily_loss_cents <= 0 {
            bail!("target profit, max risk and daily loss limit must be positive");
        }
        if !["immediate_or_cancel", "good_till_canceled", "fill_or_kill"].contains(&cfg.time_in_force.as_str()) {
            bail!("unsupported KALSHI_TIME_IN_FORCE: {}", cfg.time_in_force);
        }
        Ok(cfg)
    }
}
