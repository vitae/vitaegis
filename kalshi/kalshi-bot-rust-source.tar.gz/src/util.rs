//! Logging into stdout (journald on the server) plus a ring buffer the dashboard shows.

use std::collections::VecDeque;
use std::sync::{LazyLock, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};

pub static LOG_RING: LazyLock<Mutex<VecDeque<String>>> = LazyLock::new(|| Mutex::new(VecDeque::with_capacity(200)));

pub fn log(level: &str, msg: String) {
    let line = format!("{} {} {}", chrono::Local::now().format("%H:%M:%S"), level, msg);
    println!("{line}");
    let mut ring = LOG_RING.lock().unwrap();
    if ring.len() >= 200 {
        ring.pop_front();
    }
    ring.push_back(line);
}

#[macro_export]
macro_rules! info { ($($t:tt)*) => { $crate::util::log("INFO", format!($($t)*)) } }
#[macro_export]
macro_rules! warn { ($($t:tt)*) => { $crate::util::log("WARNING", format!($($t)*)) } }
#[macro_export]
macro_rules! error { ($($t:tt)*) => { $crate::util::log("ERROR", format!($($t)*)) } }

pub fn now() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs_f64()
}

/// "2026-11-01T02:30:00Z" -> unix seconds.
pub fn parse_ts(s: &str) -> Option<f64> {
    chrono::DateTime::parse_from_rfc3339(s).ok().map(|d| d.timestamp_millis() as f64 / 1000.0)
}
