//! Trading state and decisions. Pure, synchronous logic: the main loop does all I/O.

use crate::btc::Btc;
use crate::auto::AutoState;
use crate::config::Config;
use crate::model::{contracts_for, dollars_to_cents, fee_cents, pnl_from_payout, spread, Kind, Strategy};
use std::sync::{Arc, Mutex};
use tokio::sync::Notify;
use crate::util::{now, LOG_RING};
use crate::{error, info, warn};
use serde::Serialize;
use serde_json::{json, Value};
use std::collections::{HashMap, HashSet};

pub struct Order {
    pub client_order_id: String,
    pub side: &'static str,
    pub price: i64,
    pub count: i64,
    pub fill_count: Option<i64>,
    pub avg_fill: Option<i64>,
    pub fee: Option<i64>,
}

pub struct Watched {
    pub ticker: String,
    pub close: f64, // unix seconds
    pub close_time: String,
    pub title: Option<String>,
    pub strike: Option<f64>,
    pub path: Vec<(i64, Option<i64>, Option<i64>)>,
    pub orders: Vec<Order>,
    pub last_quote: Option<(Option<i64>, Option<i64>)>,
}

#[derive(Serialize, Clone)]
pub struct Trade {
    pub ticker: String,
    pub title: Option<String>,
    pub at: f64,
    pub live: bool,
    pub side: &'static str,
    pub price: i64,
    pub count: i64,
    pub filled: Option<i64>,
    pub risk: i64,
    pub win: i64,
    pub seconds_left: i64,
    pub model_p: Option<f64>,
    pub btc: Option<f64>,
    pub strike: Option<f64>,
    pub latency_ms: Option<u128>,
    pub strategy: String,
    pub expected_win: Option<f64>, // backtest win rate of the strategy when it was picked
    pub slippage: Option<i64>,     // average fill minus limit, cents (positive = paid more)
    pub client_order_id: String,
    pub result: Option<String>,
    pub pnl: Option<i64>,
}

#[derive(Serialize, Clone)]
pub struct Decision {
    pub action: &'static str,
    pub reason: String,
}

/// What the decision needs from outside the bot lock (read first: lock order is
/// auto -> strategy -> btc -> bot -> disabled).
pub struct Ctx {
    pub strategy: Option<Strategy>,
    pub mom: Option<f64>,
    pub auto_status: Option<String>,
    pub btc_age: Option<f64>,
    pub expected_win: Option<f64>,
    pub btc_price: Option<f64>,
    pub btc_vol: Option<f64>,
}

pub struct Intent {
    pub strategy: String,
    pub expected_win: Option<f64>,
    pub ticker: String,
    pub side: &'static str,
    pub price: i64,
    pub count: i64,
    pub close_in: i64,
    pub client_order_id: String,
}

pub struct Bot {
    pub cfg: Config,
    pub watched: HashMap<String, Watched>,
    pub current: Option<String>,
    pub traded: HashSet<String>,
    pub orders_today: i64,
    pub pnl_today: i64,
    pub halted_logged: bool,
    pub today: chrono::NaiveDate,
    pub trades: Vec<Trade>,
    pub decision: Decision,
    pub started: f64,
    pub balance: Option<i64>,
    pub peak_balance: Option<i64>,
    pub halt_reason: Option<String>,
    pub order_failures: u32,
    pub streaming: bool,
    /// Strategies paused after live losses ("edge decay"), label -> paused until (unix s).
    /// Shared with the auto-test so it picks something else.
    pub disabled: Arc<Mutex<std::collections::HashMap<String, f64>>>,
    pub retest: Arc<Notify>,
}

const MAX_PATH_POINTS: usize = 400;

impl Bot {
    pub fn new(cfg: Config) -> Self {
        Bot {
            cfg,
            watched: HashMap::new(),
            current: None,
            traded: HashSet::new(),
            orders_today: 0,
            pnl_today: 0,
            halted_logged: false,
            today: chrono::Local::now().date_naive(),
            trades: Vec::new(),
            decision: Decision { action: "starting", reason: "Waiting for the first quote.".into() },
            started: now(),
            balance: None,
            peak_balance: None,
            halt_reason: None,
            order_failures: 0,
            streaming: false,
            disabled: Arc::new(Mutex::new(HashMap::new())),
            retest: Arc::new(Notify::new()),
        }
    }

    pub fn halt(&mut self, reason: String) {
        if self.halt_reason.is_none() {
            error!("HALTED: {reason}");
            self.halt_reason = Some(reason);
        }
    }

    /// Balance update with the drawdown breaker: halt if it falls `drawdown_stop` below its peak.
    pub fn set_balance(&mut self, b: i64) {
        self.balance = Some(b);
        let peak = self.peak_balance.map_or(b, |p| p.max(b));
        self.peak_balance = Some(peak);
        if b < self.cfg.min_balance_cents {
            self.halt(format!("balance ${:.2} is under the ${:.2} floor", b as f64 / 100.0, self.cfg.min_balance_cents as f64 / 100.0));
        } else if self.cfg.drawdown_stop > 0.0 && peak > 0 && (b as f64) < peak as f64 * (1.0 - self.cfg.drawdown_stop) {
            self.halt(format!("balance ${:.2} is {:.0}% below its peak ${:.2} (drawdown breaker)", b as f64 / 100.0, self.cfg.drawdown_stop * 100.0, peak as f64 / 100.0));
        }
    }

    pub fn new_day_check(&mut self) {
        let d = chrono::Local::now().date_naive();
        if d != self.today {
            self.today = d;
            self.orders_today = 0;
            self.pnl_today = 0;
            self.halted_logged = false;
        }
    }

    /// Track the soonest-closing market from a REST poll.
    pub fn set_market(&mut self, m: &Value) -> Option<(String, Option<i64>, Option<i64>)> {
        let ticker = m["ticker"].as_str()?.to_string();
        let close_time = m["close_time"].as_str()?.to_string();
        let w = self.watched.entry(ticker.clone()).or_insert_with(|| Watched {
            ticker: ticker.clone(),
            close: crate::util::parse_ts(&close_time).unwrap_or(0.0),
            close_time,
            title: m["title"].as_str().map(String::from),
            strike: None,
            path: Vec::new(),
            orders: Vec::new(),
            last_quote: None,
        });
        if let Some(s) = m["floor_strike"].as_f64() {
            w.strike = Some(s);
        }
        self.current = Some(ticker.clone());
        Some((ticker, dollars_to_cents(m.get("yes_ask_dollars")), dollars_to_cents(m.get("no_ask_dollars"))))
    }

    /// Record a quote and decide. Returns an order to place, if any.
    pub fn observe(&mut self, ticker: &str, yes: Option<i64>, no: Option<i64>, source: &str, c: &Ctx) -> Option<Intent> {
        let (strategy, mom, auto_status) = (c.strategy, c.mom, c.auto_status.as_deref());
        if self.current.as_deref() != Some(ticker) {
            return None;
        }
        let w = self.watched.get_mut(ticker)?;
        let close_in = (w.close - now()) as i64;
        if close_in <= 0 {
            return None;
        }
        let changed = w.last_quote != Some((yes, no));
        if changed || source == "rest" {
            info!("{source:<4} {ticker} closes in {close_in}s | YES ask {}¢ | NO ask {}¢", fmt(yes), fmt(no));
        }
        if changed {
            w.last_quote = Some((yes, no));
            if w.path.len() < MAX_PATH_POINTS {
                w.path.push((close_in, yes, no));
            }
        }

        let hold = |bot: &mut Bot, action: &'static str, reason: String| {
            if bot.decision.reason != reason && action != "wait" {
                info!("decision: {action} — {reason}");
            }
            bot.decision = Decision { action, reason };
            None
        };
        if let Some(h) = self.halt_reason.clone() {
            return hold(self, "stop", format!("Bot halted: {h}. Fix it and restart."));
        }
        if self.traded.contains(ticker) {
            return hold(self, "done", "Already traded this market (one order per market). Waiting for it to settle.".into());
        }
        if self.orders_today >= self.cfg.max_orders_per_day {
            return hold(self, "stop", format!("Daily cap of {} trades reached.", self.cfg.max_orders_per_day));
        }
        if self.pnl_today <= -self.cfg.daily_loss_cents {
            if !self.halted_logged {
                self.halted_logged = true;
                warn!("daily loss limit hit ({:+.2}); no more trades today", self.pnl_today as f64 / 100.0);
            }
            return hold(self, "stop", format!("Daily loss limit hit ({:+.2}). Paused until tomorrow.", self.pnl_today as f64 / 100.0));
        }
        let Some(st) = strategy else {
            let why = auto_status.unwrap_or("no strategy");
            return hold(self, "wait", format!("Sitting out — {why}. The next auto-test runs within the hour."));
        };
        let label = st.label();
        let paused_until = self.disabled.lock().unwrap().get(&label).copied().filter(|u| *u > now());
        if let Some(until) = paused_until {
            let mins = ((until - now()) / 60.0) as i64;
            return hold(self, "stop", format!("'{label}' is paused after live losses (edge decay) for {mins} more min; waiting for the auto-test to pick another."));
        }
        if close_in > st.tmax {
            return hold(self, "wait", format!("Buy window opens at {}:{:02} left (in {}s).", st.tmax / 60, st.tmax % 60, close_in - st.tmax));
        }
        if close_in < st.tmin {
            return hold(self, "closed", format!("Buy window is over for this market (it ends at {}:{:02} left). Next market soon.", st.tmin / 60, st.tmin % 60));
        }
        if let Some(sp) = spread(yes, no).filter(|sp| *sp > self.cfg.max_spread) {
            return hold(self, "wait", format!("Book too thin: spread {sp}¢ is over the {}¢ limit, so the price is unreliable.", self.cfg.max_spread));
        }
        if st.kind == Kind::Momentum && c.btc_age.is_none_or(|a| a > self.cfg.btc_stale_secs) {
            return hold(self, "wait", format!("BTC price feed is stale ({}); momentum needs a fresh price.", c.btc_age.map_or("no data".into(), |a| format!("{a:.0}s old"))));
        }
        let p_yes = match (c.btc_price, c.btc_vol) {
            (Some(p), Some(v)) => self.watched.get(ticker).and_then(|w| w.strike).map(|k| crate::model::prob(p, k, v, close_in)),
            _ => None,
        };
        if st.kind == Kind::Edge && (p_yes.is_none() || c.btc_age.is_none_or(|a| a > self.cfg.btc_stale_secs)) {
            return hold(self, "wait", "Model edge needs a fresh BTC price, volatility and the market's strike.".into());
        }
        let Some((side, price)) = st.entry_with(yes, no, close_in, mom, p_yes) else {
            let reason = match st.kind {
                Kind::Edge => {
                    let p = p_yes.unwrap_or(0.5);
                    format!("Model says YES {:.0}% vs price {}¢ / NO {:.0}% vs {}¢: edge under {:.0} pts after fees.", p * 100.0, fmt(yes), (1.0 - p) * 100.0, fmt(no), st.thr * 100.0)
                }
                crate::model::Kind::Momentum => format!(
                    "BTC 5-min move {} (needs ±{:.2}%) and that side priced {}–{}¢. YES {}¢ / NO {}¢.",
                    mom.map(|m| format!("{:+.3}%", m * 100.0)).unwrap_or_else(|| "unknown".into()), st.thr * 100.0, st.lo, st.hi, fmt(yes), fmt(no)
                ),
                crate::model::Kind::Zone => format!("Neither side is priced {}–{}¢ (YES {}¢ / NO {}¢). Watching every price change.", st.lo, st.hi, fmt(yes), fmt(no)),
            };
            return hold(self, "wait", reason);
        };
        let mut count = contracts_for(self.cfg.target_cents, self.cfg.max_risk_cents, price);
        // Optional fractional-Kelly cap on top of the fixed-risk sizing (needs a balance and a model probability).
        if self.cfg.kelly_fraction > 0.0 {
            if let (Some(bal), Some(p)) = (self.balance, p_yes.map(|p| if side == "yes" { p } else { 1.0 - p })) {
                let stake = crate::model::kelly_fraction(p, price, self.cfg.kelly_fraction) * bal as f64;
                count = count.min((stake / price as f64).floor() as i64);
            }
        }
        if count < 1 {
            return hold(self, "wait", format!("Max risk ${:.2} can't buy one contract at {price}¢.", self.cfg.max_risk_cents as f64 / 100.0));
        }
        // Last line of defence against a silent bug betting the wrong side or size: halt instead.
        if let Err(bug) = sanity(&st, side, price, count, yes, no, if st.kind == Kind::Momentum { mom } else { None }, self.cfg.max_risk_cents) {
            self.halt(format!("sanity check failed before ordering: {bug}"));
            return hold(self, "stop", format!("Bot halted: sanity check failed ({bug})."));
        }
        self.decision = Decision { action: "buy", reason: format!("{} at {price}¢ with {close_in}s left matches '{}': buying {count}.", side.to_uppercase(), st.label()) };
        let win = count * (100 - price) - fee_cents(count, price);
        info!(
            "[{}] buy {count}x {} @ {price}¢ on {ticker} (risk ${:.2}, win nets ~${:.2})",
            if self.cfg.live { "LIVE" } else { "DRY-RUN" }, side.to_uppercase(), (count * price) as f64 / 100.0, win as f64 / 100.0
        );
        self.traded.insert(ticker.to_string());
        self.orders_today += 1;
        Some(Intent { strategy: label, expected_win: c.expected_win, ticker: ticker.to_string(), side, price, count, close_in, client_order_id: uuid::Uuid::new_v4().to_string() })
    }

    /// Store an order after it was sent (or simulated). `resp` is Kalshi's response in live mode.
    pub fn record_order(&mut self, it: &Intent, resp: Option<&Value>, latency_ms: Option<u128>, btc: &Btc) {
        let fill_count = resp.and_then(|r| r.get("fill_count")).and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()).or(v.as_f64())).map(|f| f as i64);
        let avg_fill = resp.and_then(|r| dollars_to_cents(r.get("average_fill_price")));
        let fee = match (resp.and_then(|r| r.get("average_fee_paid")).and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()).or(v.as_f64())), fill_count) {
            (Some(f), Some(n)) if n > 0 => Some((f * 100.0 * n as f64).round() as i64),
            _ => None,
        };
        if let Some(r) = resp {
            info!("order {} filled {}/{} avg {}¢ fee {}¢ in {}ms", r["order_id"].as_str().unwrap_or("?"), fill_count.map_or("?".into(), |n| n.to_string()), it.count, fmt(avg_fill), fmt(fee), latency_ms.unwrap_or(0));
        }
        let Some(w) = self.watched.get_mut(&it.ticker) else { return };
        w.orders.push(Order { client_order_id: it.client_order_id.clone(), side: it.side, price: it.price, count: it.count, fill_count, avg_fill, fee });
        self.trades.push(Trade {
            ticker: it.ticker.clone(),
            title: w.title.clone(),
            at: now(),
            live: self.cfg.live,
            side: it.side,
            price: avg_fill.unwrap_or(it.price),
            count: it.count,
            filled: if self.cfg.live { fill_count } else { Some(it.count) },
            risk: it.count * it.price,
            win: it.count * (100 - it.price) - fee_cents(it.count, it.price),
            seconds_left: it.close_in,
            model_p: btc.prob(w.strike, it.close_in),
            btc: btc.price,
            strike: w.strike,
            latency_ms,
            strategy: it.strategy.clone(),
            expected_win: it.expected_win,
            slippage: avg_fill.map(|f| f - it.price),
            client_order_id: it.client_order_id.clone(),
            result: None,
            pnl: None,
        });
    }

    /// Markets past close + grace that still need a result.
    pub fn due_for_settlement(&self) -> Vec<String> {
        let t = now();
        self.watched.values().filter(|w| t >= w.close + self.cfg.settle_grace as f64).map(|w| w.ticker.clone()).collect()
    }

    /// `yes_payout`: cents a YES contract paid (100 / 0, or something else for an unusual
    /// settlement such as a void). None = not settled yet.
    pub fn settle(&mut self, ticker: &str, result: &str, yes_payout: Option<i64>) {
        let Some(w) = self.watched.get(ticker) else { return };
        let Some(yes_payout) = yes_payout else {
            if now() > w.close + self.cfg.settle_timeout as f64 {
                error!("{ticker} never settled; dropping. Check its orders on kalshi.com.");
                self.watched.remove(ticker);
            }
            return;
        };
        if yes_payout != 0 && yes_payout != 100 {
            warn!("{ticker} settled unusually ({result}, YES paid {yes_payout}¢); P&L uses that payout");
        }
        let w = self.watched.remove(ticker).unwrap();
        for o in &w.orders {
            let contracts = if self.cfg.live { o.fill_count.unwrap_or(0) } else { o.count };
            let price = o.avg_fill.unwrap_or(o.price);
            let fee = o.fee.unwrap_or_else(|| fee_cents(contracts, price));
            let pnl = pnl_from_payout(o.side, contracts, price, fee, yes_payout);
            self.pnl_today += pnl;
            info!("{ticker} settled {}: {} {contracts}x @ {price}¢ -> {:+.2}", result.to_uppercase(), o.side.to_uppercase(), pnl as f64 / 100.0);
            let mut label = None;
            if let Some(t) = self.trades.iter_mut().find(|t| t.client_order_id == o.client_order_id) {
                t.result = Some(result.to_string());
                t.pnl = Some(pnl);
                if contracts > 0 {
                    label = Some(t.strategy.clone());
                }
            }
            if let Some(l) = label {
                self.check_decay(&l);
            }
        }
    }

    /// Edge-decay guard: if a strategy's last N filled trades lost more than the limit, pause it
    /// for 24h and ask the auto-test to pick again. Backtests can't see an edge fading; live P&L can.
    fn check_decay(&mut self, label: &str) {
        let n = self.cfg.decay_trades;
        let recent: Vec<i64> = self.trades.iter().rev().filter(|t| t.strategy == label && t.pnl.is_some() && t.filled.unwrap_or(0) > 0).take(n).filter_map(|t| t.pnl).collect();
        let net: i64 = recent.iter().sum();
        if recent.len() >= n.min(4) && net <= -self.cfg.decay_stop_cents {
            warn!("edge decay: '{label}' lost {:.2} over its last {} trades; pausing it for 24h and re-testing", net as f64 / 100.0, recent.len());
            self.disabled.lock().unwrap().insert(label.to_string(), now() + 86_400.0);
            self.retest.notify_one();
        }
    }

    /// Live results split by strategy and by side: the blog's lesson that one bucket can quietly
    /// give back what another earns.
    fn breakdown(&self) -> Value {
        let mut by: std::collections::BTreeMap<(String, &'static str), (i64, i64, i64, i64, Option<f64>, i64)> = Default::default();
        for t in self.trades.iter().filter(|t| t.pnl.is_some() && (!self.cfg.live || t.filled.unwrap_or(0) > 0)) {
            for key in [(t.strategy.clone(), "all"), (t.strategy.clone(), t.side)] {
                let e = by.entry(key).or_insert((0, 0, 0, 0, t.expected_win, 0));
                e.0 += 1;
                e.1 += (t.pnl.unwrap() > 0) as i64;
                e.2 += t.pnl.unwrap();
                e.3 += t.price;
                e.5 += t.slippage.unwrap_or(0);
            }
        }
        let disabled = self.disabled.lock().unwrap().clone();
        let rows: Vec<Value> = by
            .into_iter()
            .map(|((label, side), (n, w, net, sum_px, exp, slip))| {
                json!({
                    "strategy": label, "side": side, "trades": n, "wins": w, "net": net,
                    "avg_entry": sum_px as f64 / n as f64, "expected_win": exp, "slippage": slip,
                    "paused_until": disabled.get(&label).copied().filter(|u| *u > now()),
                })
            })
            .collect();
        json!(rows)
    }

    /// Everything the dashboard shows (same JSON shape as the Python bot).
    pub fn snapshot(&self, btc: &Btc, strategy: Option<Strategy>, auto: Option<&AutoState>) -> Value {
        let t = now();
        let market = self.current.as_ref().and_then(|tk| self.watched.get(tk)).map(|w| {
            let (yes, no) = w.last_quote.unwrap_or((None, None));
            let left = ((w.close - t) as i64).max(0);
            let p = btc.prob(w.strike, left);
            let edge = |prob: Option<f64>, ask: Option<i64>| -> Option<f64> {
                let (prob, ask) = (prob?, ask? as f64);
                Some(((100.0 * prob - ask - 7.0 * (ask / 100.0) * (1.0 - ask / 100.0)) * 10.0).round() / 10.0)
            };
            let path: Vec<Value> = w.path.iter().rev().take(200).rev().map(|&(s, y, n)| json!([s, y, n])).collect();
            json!({
                "ticker": w.ticker, "title": w.title, "close_time": w.close_time, "seconds_left": left,
                "yes": yes, "no": no, "strike": w.strike, "path": path,
                "model_yes": p, "edge_yes": edge(p, yes), "edge_no": edge(p.map(|x| 1.0 - x), no),
                "traded": self.traded.contains(&w.ticker),
            })
        });
        let settled: Vec<&Trade> = self.trades.iter().filter(|t| t.pnl.is_some()).collect();
        json!({
            "now": t, "uptime": t - self.started, "live": self.cfg.live, "streaming": self.streaming,
            "balance": self.balance, "market": market, "decision": self.decision,
            "btc": {"price": btc.price, "vol_1m": btc.vol, "history": btc.history.iter().rev().take(60).rev().map(|&(a, b)| json!([a, b])).collect::<Vec<_>>(), "ok": btc.ok},
            "config": {
                "min_entry": self.cfg.min_entry, "max_entry": self.cfg.max_entry, "min_seconds": self.cfg.min_seconds,
                "target": self.cfg.target_cents as f64 / 100.0, "max_risk": self.cfg.max_risk_cents as f64 / 100.0,
                "daily_loss": self.cfg.daily_loss_cents as f64 / 100.0, "max_orders": self.cfg.max_orders_per_day,
            },
            "today": {"orders": self.orders_today, "pnl": self.pnl_today, "wins": settled.iter().filter(|t| t.pnl.unwrap_or(0) > 0).count(), "settled": settled.len()},
            "trades": self.trades.iter().rev().take(50).collect::<Vec<_>>(),
            "log": LOG_RING.lock().unwrap().iter().cloned().collect::<Vec<_>>(),
            "halt": self.halt_reason,
            "strategy": strategy.map(|s| json!({"kind": s.kind, "lo": s.lo, "hi": s.hi, "tmin": s.tmin, "tmax": s.tmax, "thr": s.thr, "label": s.label()})),
            "momentum": btc.momentum(),
            "auto": auto,
            "breakdown": self.breakdown(),
            "guards": {"max_spread": self.cfg.max_spread, "btc_stale_secs": self.cfg.btc_stale_secs, "decay_trades": self.cfg.decay_trades, "decay_stop": self.cfg.decay_stop_cents as f64 / 100.0, "drawdown_stop": self.cfg.drawdown_stop, "check_depth": self.cfg.check_depth, "peak_balance": self.peak_balance},
        })
    }
}

/// Independent re-check of an order before it is sent. Any failure means a bug, not a market
/// condition, so the caller halts the bot.
#[allow(clippy::too_many_arguments)]
pub fn sanity(st: &Strategy, side: &str, price: i64, count: i64, yes: Option<i64>, no: Option<i64>, mom: Option<f64>, max_risk: i64) -> Result<(), String> {
    let ask = match side {
        "yes" => yes,
        "no" => no,
        _ => return Err(format!("unknown side {side}")),
    };
    if ask != Some(price) {
        return Err(format!("{side} price {price}¢ isn't that side's ask ({ask:?})"));
    }
    if !(1..=99).contains(&price) || price < st.lo || price > st.hi {
        return Err(format!("price {price}¢ outside {}–{}¢", st.lo, st.hi));
    }
    if count < 1 || count * price > max_risk {
        return Err(format!("{count} contracts at {price}¢ breaks the ${:.2} risk cap", max_risk as f64 / 100.0));
    }
    if st.kind == Kind::Momentum {
        let m = mom.ok_or("momentum trade without a BTC move")?;
        let want = if m > 0.0 { "yes" } else { "no" };
        if side != want {
            return Err(format!("BTC moved {:+.3}% but the order buys {side}", m * 100.0));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mom() -> Strategy {
        Strategy { kind: Kind::Momentum, lo: 35, hi: 65, tmin: 300, tmax: 600, thr: 0.001 }
    }

    #[test]
    fn sanity_catches_sign_flips_and_size() {
        assert!(sanity(&mom(), "yes", 55, 14, Some(55), Some(46), Some(0.002), 800).is_ok());
        // the blog's costliest bug: backing the wrong side
        assert!(sanity(&mom(), "no", 46, 14, Some(55), Some(46), Some(0.002), 800).is_err());
        assert!(sanity(&mom(), "yes", 46, 14, Some(55), Some(46), Some(0.002), 800).is_err()); // wrong price
        assert!(sanity(&mom(), "yes", 55, 20, Some(55), Some(46), Some(0.002), 800).is_err()); // over risk
        assert!(sanity(&mom(), "yes", 70, 10, Some(70), Some(31), Some(0.002), 800).is_err()); // outside band
    }

    #[test]
    fn decay_guard_pauses_a_losing_strategy() {
        let mut cfg = crate::config::Config::from_env(false).unwrap();
        cfg.decay_trades = 4;
        cfg.decay_stop_cents = 1000;
        let mut bot = Bot::new(cfg);
        for i in 0..4 {
            bot.trades.push(Trade {
                ticker: format!("T{i}"), title: None, at: 0.0, live: false, side: "yes", price: 50, count: 16, filled: Some(16),
                risk: 800, win: 772, seconds_left: 400, model_p: None, btc: None, strike: None, latency_ms: None,
                strategy: "S".into(), expected_win: Some(0.58), slippage: None, client_order_id: format!("c{i}"), result: Some("no".into()), pnl: Some(-800),
            });
        }
        bot.check_decay("S");
        assert!(bot.disabled.lock().unwrap().contains_key("S"));
    }
}

fn fmt(v: Option<i64>) -> String {
    v.map_or("None".into(), |x| x.to_string())
}
