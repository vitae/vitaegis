#!/usr/bin/env bash
# One-time setup on a fresh Ubuntu 24.04 EC2 instance (us-east-1). Run from the unpacked folder:
#   sudo bash deploy/setup.sh
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f kalshi-bot ] || { echo "kalshi-bot binary missing next to deploy/"; exit 1; }
[ -f kalshi_private.key ] || { echo "Copy your Kalshi private key here as kalshi_private.key first"; exit 1; }

timedatectl set-ntp true   # Kalshi rejects signatures with a wrong clock
id kalshi >/dev/null 2>&1 || useradd --system --home /opt/kalshi-bot --shell /usr/sbin/nologin kalshi
install -d -o kalshi -g kalshi -m 750 /opt/kalshi-bot
install -o kalshi -g kalshi -m 755 kalshi-bot /opt/kalshi-bot/kalshi-bot
install -o kalshi -g kalshi -m 600 kalshi_private.key /opt/kalshi-bot/kalshi_private.key
shred -u kalshi_private.key || rm -f kalshi_private.key
[ -f /etc/kalshi-bot.env ] || install -m 600 deploy/kalshi-bot.env.example /etc/kalshi-bot.env
install -m 644 deploy/kalshi-bot.service /etc/systemd/system/kalshi-bot.service
systemctl daemon-reload

echo
echo "Dry run (no orders) to check your key:"
sudo -u kalshi env $(grep -v '^#' /etc/kalshi-bot.env | sed 's/#.*//' | xargs) /opt/kalshi-bot/kalshi-bot --once || true
echo
echo "If that said 'auth ok', start trading with:"
echo "  sudo systemctl enable --now kalshi-bot && journalctl -u kalshi-bot -f"
