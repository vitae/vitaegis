# kalshi-bot (Rust)

Vitaegis bot for Kalshi's 15-minute Bitcoin markets (KXBTC15M). Single static-ish binary,
~4 MB, runs on a $3–8/month EC2 instance in us-east-1 (Kalshi's own AWS region).

What it does
- Streams quotes over Kalshi's WebSocket (Ed25519 or RSA key) and reacts to each change.
- Hourly auto-test: replays 40 candidate strategies (price zones, BTC momentum, GBM model-edge)
  on the last ~300 settled markets with 1-minute candles and Coinbase BTC prices, and trades only
  a strategy that made money in BOTH the older and newer half (≥12 trades each). Else it sits out.
- Sizing: enough contracts that a win nets ~KALSHI_TARGET_PROFIT_USD after fees, capped by
  KALSHI_MAX_RISK_USD; optional fractional-Kelly cap.
- Execution guards: spread limit, stale-BTC-feed check, orderbook depth check before ordering
  (sizes down or skips), independent sanity re-check of side/price/size (halts on mismatch),
  fill slippage tracking, P&L split by strategy and side, edge-decay pause (24h) + immediate re-test.
- Safety stops: daily loss limit, daily trade cap, balance floor, 25% drawdown breaker,
  401 or 5 failed orders in a row -> halt. Unusual settlements (voids) are priced correctly.
- Dashboard at http://127.0.0.1:8787 (reach it with `ssh -L 8787:localhost:8787 ubuntu@<ip>`).

Build:  cargo build --release          Test: cargo test
Run:    kalshi-bot [--live] [--once]   Settings: deploy/kalshi-bot.env.example
Deploy: see deploy/setup.sh (Ubuntu 24.04, x86_64 — e.g. t3.micro/t3.nano in us-east-1).

Reality check: over the 300 markets tested, no strategy showed a reliable edge after fees; the
auto-test exists so the bot only trades when recent history supports it. Keep stakes small.
